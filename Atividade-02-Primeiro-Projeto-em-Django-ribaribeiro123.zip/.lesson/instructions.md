# Atividade Individual 02

**PRINCIPAL (700XP)**
- Criar o primeiro projeto Django;
- Lembrar de configurar a SECRET_KEY no replit;
- Criar o app através do comando `python3 manage.py startapp <nomedoapp>` no Shell;
- Criar a primeira view que chame o HTML da pasta templates;
- Criar a pasta templates e adicionar o link dela no settings.py;
- Dentro da pasta templates botar o arquivo HTML da Atividade Individual 01;

**EXTRA (200XP)**
- Botar conteúdo do projeto Django no Github, em um repositório público e adicionar o link aqui (pode ser em um txt separado);
- Adicionar o CSS da sua página ao seu projeto Django (se não tiver CSS, crie um).